---
name: Maqawel Brand Identity
colors:
  surface: '#f8f9fd'
  surface-dim: '#d8dade'
  surface-bright: '#f8f9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3f7'
  surface-container: '#edeef1'
  surface-container-high: '#e7e8ec'
  surface-container-highest: '#e1e2e6'
  on-surface: '#191c1f'
  on-surface-variant: '#41484e'
  inverse-surface: '#2e3134'
  inverse-on-surface: '#eff1f4'
  outline: '#71787f'
  outline-variant: '#c0c7cf'
  surface-tint: '#21648c'
  primary: '#003b58'
  on-primary: '#ffffff'
  primary-container: '#00537a'
  on-primary-container: '#8bc6f3'
  inverse-primary: '#92cdfa'
  secondary: '#00696b'
  on-secondary: '#ffffff'
  secondary-container: '#97f2f3'
  on-secondary-container: '#007072'
  tertiary: '#542e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#744203'
  on-tertiary-container: '#f8b16c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cae6ff'
  primary-fixed-dim: '#92cdfa'
  on-primary-fixed: '#001e2f'
  on-primary-fixed-variant: '#004b6f'
  secondary-fixed: '#97f2f3'
  secondary-fixed-dim: '#7ad5d7'
  on-secondary-fixed: '#002020'
  on-secondary-fixed-variant: '#004f51'
  tertiary-fixed: '#ffdcbf'
  tertiary-fixed-dim: '#ffb873'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6a3b00'
  background: '#f8f9fd'
  on-background: '#191c1f'
  surface-variant: '#e1e2e6'
  accent-yellow: '#FDB913'
  accent-orange: '#F37021'
  surface-gray: '#F9FAFB'
  rating-gold: '#FACC15'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-page: 1.25rem
  gutter-grid: 1rem
  stack-xs: 0.25rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 1.5rem
  stack-xl: 2rem
---

## Brand & Style

The brand identity is built around the concept of "Maqawel" (مقاول), a professional, reliable, and accessible platform for contracting and home services. The UI evokes a sense of trust, efficiency, and local community. 

The design style is **Corporate / Modern** with a focus on high-quality utility. It utilizes a clean, white-dominant aesthetic to ensure maximum readability and a "fresh" feel, common in professional service industries. The interface prioritizes clarity through a strictly Right-to-Left (RTL) layout, ensuring a native experience for Arabic-speaking users. Visual elements are professional yet approachable, using the primary blue and green accents from the logo to signify stability and growth.

## Colors

The palette is derived directly from the new logo to maintain brand consistency. The **Primary Color** is a deep, professional blue (#00537A), used for main headers, primary actions, and navigational elements to establish authority. The **Secondary Color** is a teal-leaning green (#007A7C), representing service execution and positive outcomes.

We utilize **accent colors** from the logo—yellow and orange—sparingly for notifications, ratings, or highlighting specific status changes. The background remains a clean, high-contrast white to support the RTL typography and maintain a modern, uncluttered look.

## Typography

This design system uses **Plus Jakarta Sans** for its modern, friendly, and geometric qualities which pair excellently with contemporary Arabic typefaces. The hierarchy is designed to be clear and functional, with a strong emphasis on bold headlines for screen titles.

All typography is strictly aligned to the right. Line heights are slightly generous to accommodate the taller ascenders and descenders common in Arabic script, ensuring that text does not feel cramped or illegible.

## Layout & Spacing

The layout follows a **fluid grid** model optimized for mobile-first consumption. 
- **Margins:** Standard side margins are set at 20px (1.25rem) to provide breathing room on small screens.
- **Grid:** A 4-column system is used for mobile, expanding to 8 or 12 for tablet/desktop views.
- **RTL Logic:** Spacing and layout are mirrored; for example, a "padding-left" in a LTR context is applied as "padding-right" here.
- **Stacking:** Vertical spacing follows a consistent 4px or 8px base unit to ensure rhythmic harmony between components.

## Elevation & Depth

To maintain a clean and corporate look, the system uses **Tonal Layers** and **Low-contrast outlines** rather than heavy shadows. 

- **Surface Levels:** The base background is white (#FFFFFF). Secondary containers use a very light gray (#F9FAFB) to create subtle separation.
- **Shadows:** When depth is required (e.g., for sticky buttons or floating cards), use extra-diffused, low-opacity shadows (e.g., 4% opacity) with a slight blue tint from the primary color to prevent them from looking "dirty."
- **Borders:** Use subtle 1px borders (#E5E7EB) for input fields and cards to define boundaries without adding visual weight.

## Shapes

The design system adopts a **Rounded** shape language (0.5rem base radius). This strikes a balance between the precision of the contracting industry and the approachability of a consumer app. 

- **Standard Elements:** Buttons, cards, and input fields use the 0.5rem radius.
- **Large Elements:** Onboarding cards or featured banners use 1rem (rounded-lg).
- **Interactive Small Elements:** Chips and tags use 1.5rem (rounded-xl) or a full pill shape to distinguish them as easily tappable metadata.

## Components

### Buttons
- **Primary:** Solid #00537A with white text. High emphasis for "Submit" or "Join" actions.
- **Secondary:** Solid #007A7C with white text. Used for secondary contact methods like WhatsApp.
- **Ghost:** Transparent with primary color border and text. Used for less critical actions.

### Cards & Lists
- Cards should have a subtle 1px border.
- In list items, the chevron icon for "Next" must point to the left (←) to reflect the RTL navigation flow.

### Input Fields
- Labels are right-aligned above the field. 
- Placeholders use a muted gray. 
- Focus state is indicated by a 2px primary blue border.

### Chips & Ratings
- Use the accent yellow (#FDB913) for star icons.
- Tag chips for quick reviews use a light primary tint background with primary colored text to ensure they look interactive.

### Navigation
- Sticky bottom bars for mobile should include "Contact" actions.
- Header titles are centered or right-aligned depending on the screen context.