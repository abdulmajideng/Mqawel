# Maqawel (مقاول) - Final Professional Strategy & Features
## 1. Professional Branding
- **Logo Upgrade:** Moving from a basic image to a refined, geometric vector logo that symbolizes trust, home, and professional repair.
- **Color Palette:** Deep Professional Blue (#00537a) for trust, and vibrant Green for growth and completion.

## 2. Advanced Marketplace Features
- **Mutual Rating System:** Both customers and handymen can rate each other to ensure a high-quality community.
- **Smart Discount Engine:** Integrated promotional banners and coupon codes for localized offers.
- **Comprehensive Search:** Advanced filters for location, price range, and "Verified" status.

## 3. Customer Success & Communication
- **Direct WhatsApp Support:** One-tap access to customer service at +967774404328.
- **In-App Wallet:** Full visibility of "My Wallet", "My Mobile", and "My Money" (Transactions).

## 4. Required Screens to Update/Create
1. **Home Screen (Pro V4):** Featuring the new professional logo, discount banners, and quick search.
2. **Mutual Rating Screen:** A new flow where the handyman can also rate the customer.
3. **Offers & Discounts Screen:** A dedicated place for users to find active promotions.
4. **Customer Support Screen:** Highlighting the WhatsApp contact and support hours.
5. **Wallet & Finances:** Detailed breakdown of "Pocket", "Phone Balance", and "App Balance".