# Harfi (حرفي) - Local Handyman App
## Project Overview
A fast, lightweight, strictly Right-to-Left (RTL) mobile application for local handymen and home services. The UI MUST be entirely in Arabic. The design should be clean, minimalist, and use a white background with trustworthy blue and green accents.
## Screens
### 1. Onboarding & Login Screen
*   **Header:** Title "كيف نقدر نخدمك اليوم؟"
*   **Actions:** 
    *   Large Button: "أنا زبون"
    *   Large Button: "أنا حرفي"
*   **Form:** Phone number input field with placeholder "أدخل رقم الجوال"
*   **Footer:** Primary Button "تسجيل الدخول"
### 2. Home Screen (Customer View)
*   **Search:** Search bar with placeholder "عن أيش تدور؟"
*   **Categories:** A grid of 4 category cards with icons: 
    *   "كهرباء وطاقة شمسية"
    *   "كاميرات مراقبة وشبكات"
    *   "سباكة"
    *   "نجارة وديكور"
*   **Section:** Horizontal scrolling list titled "أفضل الحرفيين تقييماً" showing small cards with user avatars, names, and 5-star ratings.
### 3. Craftsman Profile Screen
*   **Header:** Profile picture, Craftsman Name "م. أحمد", Subtitle "فني شبكات وكاميرات مراقبة".
*   **Gallery:** Section titled "معرض الأعمال" displaying a 2x2 grid of project photos.
*   **Reviews:** Section titled "التقييمات" showing 5 yellow stars (4.9 rating).
*   **Actions (Sticky Bottom):** 
    *   Primary Button (Green): "تواصل واتساب"
    *   Secondary Button (Blue): "اتصال هاتفي"
### 4. Rating Screen
*   **Header:** Title "قيّم عمل الحرفي"
*   **Rating Input:** 5 large clickable empty stars.
*   **Quick Tags:** Group of small buttons: "شغله نظيف", "سريع في الإنجاز", "سعره مناسب".
*   **Action:** Submit button "إرسال التقييم"
## Global Rules
*   Strict RTL alignment for all components.
*   All text strings must be rendered exactly as provided in Arabic.