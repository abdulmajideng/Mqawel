---
name: Harfi Design System
colors:
  surface: '#fbf8ff'
  surface-dim: '#dad9e3'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2fc'
  surface-container: '#eeedf7'
  surface-container-high: '#e8e7f1'
  surface-container-highest: '#e3e1eb'
  on-surface: '#1a1b22'
  on-surface-variant: '#444653'
  inverse-surface: '#2f3037'
  inverse-on-surface: '#f1f0fa'
  outline: '#757684'
  outline-variant: '#c4c5d5'
  surface-tint: '#3755c3'
  primary: '#00288e'
  on-primary: '#ffffff'
  primary-container: '#1e40af'
  on-primary-container: '#a8b8ff'
  inverse-primary: '#b8c4ff'
  secondary: '#006e2d'
  on-secondary: '#ffffff'
  secondary-container: '#7cf994'
  on-secondary-container: '#007230'
  tertiary: '#611e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#872d00'
  on-tertiary-container: '#ffa583'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c4ff'
  on-primary-fixed: '#001453'
  on-primary-fixed-variant: '#173bab'
  secondary-fixed: '#7ffc97'
  secondary-fixed-dim: '#62df7d'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#ffdbce'
  tertiary-fixed-dim: '#ffb59a'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#802a00'
  background: '#fbf8ff'
  on-background: '#1a1b22'
  surface-variant: '#e3e1eb'
  rating-gold: '#FACC15'
  surface-gray: '#F9FAFB'
  border-subtle: '#E5E7EB'
  text-main: '#111827'
  text-muted: '#6B7280'
typography:
  headline-lg:
    fontFamily: beVietnamPro
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: beVietnamPro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: beVietnamPro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: beVietnamPro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: beVietnamPro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: beVietnamPro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-page: 1.25rem
  gutter-grid: 1rem
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 1.5rem
---

# Harfi (حرفي) - Local Handyman App
## Project Overview
A fast, lightweight, strictly Right-to-Left (RTL) mobile application for local handymen and home services. The UI MUST be entirely in Arabic. The design should be clean, minimalist, and use a white background with trustworthy blue and green accents.
## Screens
### 1. Onboarding & Login Screen
*   **Header:** Title "كيف نقدر نخدمك اليوم؟"
*   **Actions:** 
    *   Large Button: "أنا زبون"
    *   Large Button: "أنا حرفي"
*   **Form:** Phone number input field with placeholder "أدخل رقم الجوال"
*   **Footer:** Primary Button "تسجيل الدخول"
### 2. Home Screen (Customer View)
*   **Search:** Search bar with placeholder "عن أيش دور؟"
*   **Categories:** A grid of 4 category cards with icons: 
    *   "كهرباء وطاقة شمسية"
    *   "كاميرات مراقبة وشبكات"
    *   "سباكة"
    *   "نجارة وديكور"
*   **Section:** Horizontal scrolling list titled "أفضل الحرفيين تقييماً" showing small cards with user avatars, names, and 5-star ratings.
### 3. Craftsman Profile Screen
*   **Header:** Profile picture, Craftsman Name "م. أحمد", Subtitle "فني شبكات وكاميرات مراقبة".
*   **Gallery:** Section titled "معرض الأعمال" displaying a 2x2 grid of project photos.
*   **Reviews:** Section titled "التقييمات" showing 5 yellow stars (4.9 rating).
*   **Actions (Sticky Bottom):** 
    *   Primary Button (Green): "تواصل واتساب"
    *   Secondary Button (Blue): "اتصال هاتفي"
### 4. Rating Screen
*   **Header:** Title "قيّم عمل الحرفي"
*   **Rating Input:** 5 large clickable empty stars.
*   **Quick Tags:** Group of small buttons: "شغله نظيف", "سريع في الإنجاز", "سعره مناسب".
*   **Action:** Submit button "إرسال التقييم"
## Global Rules
*   Strict RTL alignment for all components.
*   All text strings must be rendered exactly as provided in Arabic.